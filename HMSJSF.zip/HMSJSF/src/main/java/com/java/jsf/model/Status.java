package com.java.jsf.model;

public enum Status {
    ACTIVE, INACTIVE
}
